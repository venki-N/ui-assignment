import "./App.css";
import React from "react";
import { Container } from "@mui/material";
import Dashboard from "./feature/dashboard/Dashboard";

function App() {
  return (
    <div className="App">
      <Container maxWidth="sm" disableGutters={true}>
        <Dashboard />
      </Container>
    </div>
  );
}

export default App;
