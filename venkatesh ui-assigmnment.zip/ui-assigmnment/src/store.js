import { configureStore } from "@reduxjs/toolkit";
import dashboardSlice from "./feature/dashboard/dashboardSlice";

export default configureStore({
  reducer: {
    dashboard: dashboardSlice,
  },
});
