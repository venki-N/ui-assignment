import * as React from "react";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import SettingsIcon from "@mui/icons-material/Settings";
import SignalCellularAltIcon from "@mui/icons-material/SignalCellularAlt";
import ArticleIcon from "@mui/icons-material/Article";

export default function ToggleBar() {
  const [alignment, setAlignment] = React.useState("data");

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  return (
    <ToggleButtonGroup
      color="primary"
      value={alignment}
      exclusive
      onChange={handleChange}
      aria-label="Platform"
    >
      <ToggleButton value="data">
        <SettingsIcon />
        Data
      </ToggleButton>
      <ToggleButton value="summary">
        <SignalCellularAltIcon />
        Summary
      </ToggleButton>
      <ToggleButton value="logs">
        <ArticleIcon />
        Logs
      </ToggleButton>
    </ToggleButtonGroup>
  );
}
