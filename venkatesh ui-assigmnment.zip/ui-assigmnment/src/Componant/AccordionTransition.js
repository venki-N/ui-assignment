import * as React from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import PropTypes from "prop-types";
import "./style.css";

export default function AccordionTransition({ workflowSteps = [] }) {
  return (
    <div>
      {workflowSteps.map((d, id) => {
        return (
          <React.Fragment key={`${id}-${d.data_title}`}>
            <Accordion className="border">
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel${id}-content`}
                id={`panel${id}-header`}
              >
                <strong>
                  <Typography
                    variant="caption"
                    gutterBottom
                    sx={{ display: "block", fontWeight: "bold" }}
                  >
                    {d.name_title}
                  </Typography>
                </strong>
              </AccordionSummary>
              <hr />
              <AccordionDetails className="light-color">
                <Typography
                  variant="caption"
                  gutterBottom
                  sx={{ display: "block", color: "gray" }}
                >
                  {Object.entries(d.params_extra).map(([key, value], index) => (
                    <div key={`${key}-1`}>
                      <strong>
                        {key}:{typeof value === "object" ? typeof value : value}
                      </strong>{" "}
                    </div>
                  ))}
                </Typography>
              </AccordionDetails>
            </Accordion>
          </React.Fragment>
        );
      })}
    </div>
  );
}

AccordionTransition.propTypes = {
  workflowSteps: PropTypes.array,
};
