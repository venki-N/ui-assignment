import { createSlice } from "@reduxjs/toolkit";
import sampleData from "./sampleData.json";

export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState: {
    jsonData: sampleData,
  },
  reducers: {
    loadJsonData: (state, action) => {
      state.jsonData = action.payload;
    },
  },
});

export const { loadJsonData } = dashboardSlice.actions;

export const getJsonData = (state) => state?.dashboard?.jsonData;

export default dashboardSlice.reducer;
