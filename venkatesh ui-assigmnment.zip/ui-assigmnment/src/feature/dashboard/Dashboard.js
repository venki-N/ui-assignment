import React from "react";
import { useSelector } from "react-redux";
import { getJsonData } from "./dashboardSlice";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid2";
import ToggleBar from "../../Componant/ToggleBar";

import ReactTable from "../../Componant/ReactTable";
import "./style.css";
import { Button, Card, CardContent, Chip, Typography } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import CloseIcon from "@mui/icons-material/Close";
import EventIcon from "@mui/icons-material/Event";
import SaveAltIcon from "@mui/icons-material/SaveAlt";
import DirectionsRunIcon from "@mui/icons-material/DirectionsRun";
import InstallDesktopIcon from "@mui/icons-material/InstallDesktop";
import SchemaIcon from "@mui/icons-material/Schema";
import SettingsIcon from "@mui/icons-material/Settings";

import AccordionTransition from "../../Componant/AccordionTransition";

export default function Dashboard() {
  const data = useSelector(getJsonData)|| {};

  let rows = data?.table_data?.map((row) => {
    let rowObject = {};

    data.table_headers.forEach((header, i) => {
      const key = header?.name?.replace(/ /g, "_");
      const value = row[i];
      rowObject[key] = value;
    });
    return rowObject;
  });

  let columns = data?.table_headers?.map((value) => {
    const data = {
      ...value,
      headerName: value.name,
      field: value.name,
    };
    return data;
  });

  const lableStyle = {
    height: "auto",
    fontWeight: 550,
    marginRight: "5px",
    borderRadius: "5px",
    color: "rgb(189 131 237 / 87%)",
    backgroundColor: "rgb(238 226 248 / 87%)",
    border: "1px solid rgb(189 131 237 / 87%)",
    "& .MuiChip-label": {
      display: "block",
      whiteSpace: "normal",
    },
  };

  const lastRun = {
    ...lableStyle,
    padding:"5px"
  }

  return (
    <div className="container">
      <Box sx={{ flexGrow: 1 }} mt={"20px"}>
        <Grid container spacing={2}>
          <Grid size={9}>
            <Grid container spacing={2} mb={3}>
              <Grid size={8}>
                <ToggleBar />
              </Grid>
              <Grid size={4}>
                <Button
                  variant="outlined"
                  className="float-end"
                  disabled
                  startIcon={<SaveIcon />}
                >
                  Download
                </Button>
              </Grid>
            </Grid>
            <Card>
              <CardContent>
                <Chip
                  sx={lableStyle}
                  label="PROJECT NAME"
                  icon={<SettingsIcon />}
                />
                <div className="label-data">{data.project_name}</div>
                <Chip
                  sx={lableStyle}
                  label="OUTPUT DATASET NAME"
                  icon={<SchemaIcon />}
                />
                <div className="label-data">{data.output_name}</div>
                <Chip
                  sx={lastRun}
                  label="LAST RUN"
                />
                <div className="label-data">Not Available</div>
                <div className="label">Rows: {data.row_count}</div>
              </CardContent>
              <hr />
              <CardContent>
                <ReactTable rows={rows} columns={columns} />
              </CardContent>
            </Card>
          </Grid>
          <Grid size={3}>
            <Card>
              <CardContent>
                <Grid container spacing={2}>
                  <Grid size={6}>
                    <Typography variant="h6" gutterBottom>
                      Workflow
                    </Typography>
                  </Grid>
                  <Grid size={6}>
                    <CloseIcon className="margin-5" />
                    <SaveAltIcon className="margin-5" />
                    <InstallDesktopIcon className="margin-5" />
                    <DirectionsRunIcon className="margin-5" />
                    <EventIcon disabled className="margin-5" />
                  </Grid>
                </Grid>
              </CardContent>
              <hr />
              <CardContent>
                <AccordionTransition workflowSteps={data.workflow_steps} />
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
