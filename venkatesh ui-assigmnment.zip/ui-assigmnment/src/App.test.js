import { render } from "@testing-library/react";
import App from "./App";
import { Provider } from "react-redux";
import configureStore from "redux-mock-store";
const mockStore = configureStore([]);
const store = mockStore({
  jsonData: {
    output_name:"",
    project_name:"",
    table_headers: [],
    table_data: [],
    workflow_steps:[],
    row_count:{},
  },
});

test("renders dashboard", () => {
  render(
    <Provider store={store}>
      <App />
    </Provider>
  );
});
